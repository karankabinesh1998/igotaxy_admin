self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3fdd0bb2a9d8bf5319fb0e2da8fcf4dc",
    "url": "/index.html"
  },
  {
    "revision": "0f834f62e2c6c17f810b",
    "url": "/static/css/2.207e9658.chunk.css"
  },
  {
    "revision": "57ae52d6c09449e93e5f",
    "url": "/static/css/main.0767bb58.chunk.css"
  },
  {
    "revision": "0f834f62e2c6c17f810b",
    "url": "/static/js/2.4327d1de.chunk.js"
  },
  {
    "revision": "d39e0b56765a0af14c1decdca0a69bad",
    "url": "/static/js/2.4327d1de.chunk.js.LICENSE.txt"
  },
  {
    "revision": "57ae52d6c09449e93e5f",
    "url": "/static/js/main.27fd58f7.chunk.js"
  },
  {
    "revision": "7308dd93756735fe9a6a",
    "url": "/static/js/runtime-main.ef316f09.js"
  },
  {
    "revision": "7e37d5cdbfca3d138281e189f1f42a8b",
    "url": "/static/media/ad_logo.7e37d5cd.jpg"
  },
  {
    "revision": "451ef1a24ebc67fd5b9ad0540f42a3f5",
    "url": "/static/media/igotaxy_logo.451ef1a2.jpg"
  }
]);